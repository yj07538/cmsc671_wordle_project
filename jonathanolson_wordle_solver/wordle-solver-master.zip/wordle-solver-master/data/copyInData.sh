
echo -n "export default " > crane.tree.total.js
cat ../../miscworks/computed/wordle/crane.tree.total.json >> crane.tree.total.js

echo -n "export default " > crate.tree.total.js
cat ../../miscworks/computed/wordle/crate.tree.total.json >> crate.tree.total.js

echo -n "export default " > slate.tree.total.js
cat ../../miscworks/computed/wordle/slate.tree.total.json >> slate.tree.total.js

echo -n "export default " > trace.tree.total.js
cat ../../miscworks/computed/wordle/trace.tree.total.json >> trace.tree.total.js

echo -n "export default " > salet.tree.total.js
cat ../../miscworks/computed/wordle/salet.tree.total.json >> salet.tree.total.js

echo -n "export default " > reast.tree.total.js
cat ../../miscworks/computed/wordle/reast.tree.total.json >> reast.tree.total.js

echo -n "export default " > alter.tree.js
cat ../../miscworks/computed/wordle/alter.tree.json >> alter.tree.js

echo -n "export default " > lance.tree.js
cat ../../miscworks/computed/wordle/lance.tree.json >> lance.tree.js

echo -n "export default " > rance.tree.js
cat ../../miscworks/computed/wordle/rance.tree.json >> rance.tree.js

echo -n "export default " > rated.tree.js
cat ../../miscworks/computed/wordle/rated.tree.json >> rated.tree.js

echo -n "export default " > rants.tree.js
cat ../../miscworks/computed/wordle/rants.tree.json >> rants.tree.js

echo -n "export default " > ronte.tree.js
cat ../../miscworks/computed/wordle/ronte.tree.json >> ronte.tree.js

echo -n "export default " > salet.tree.hard.js
cat ../../miscworks/computed/wordle-hard/salet.tree.hard.json >> salet.tree.hard.js

echo -n "export default " > cramp.tree.hard.js
cat ../../miscworks/computed/wordle-hard/cramp.tree.hard.json >> cramp.tree.hard.js
